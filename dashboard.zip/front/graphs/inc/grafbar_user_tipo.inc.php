<?php

error_reporting(E_ERROR | E_PARSE);

if($data_ini == $data_fin) {
	$datas = "LIKE '".$data_ini."%'";
}

else {
	$datas = "BETWEEN '".$data_ini." 00:00:00' AND '".$data_fin." 23:59:59'";
}

$sql_grpb = "
SELECT `glpi_users`.`id` AS uid, `glpi_users`.`firstname` AS name ,`glpi_users`.`realname` AS sname, count(glpi_tickets_users.id) AS conta
FROM glpi_tickets_users, glpi_users, glpi_tickets
WHERE glpi_tickets_users.users_id = glpi_users.id
AND glpi_tickets.id = glpi_tickets_users.tickets_id
AND glpi_tickets.type = ".$id_tip."
AND (glpi_tickets.date ".$datas." OR glpi_tickets.closedate ".$datas.")
AND glpi_tickets_users.type = 2
AND glpi_tickets.is_deleted = 0
".$entidade_a."
GROUP BY uid
ORDER BY conta DESC
LIMIT 10 ";

$query_grp_b = $DB->query($sql_grpb);


echo "
<script type='text/javascript'>

$(function () {
        $('#graf_user').highcharts({
            chart: {
                type: 'bar',
                height: 550
            },
            title: {
                text: '".__('Tickets','dashboard')." ".__('by Technician','dashboard')."'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
            categories: ";

				$categories = array();
				while ($grupo = $DB->fetchAssoc($query_grp_b)) {
					$categories[] = $grupo['name']." ".$grupo['sname'];
				}
				echo json_encode($categories);
				
				echo ",
                title: {
                    text: null
                },
                labels: {
                	style: {
                        fontSize: '12px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    },
                     borderWidth: 1,
                	borderColor: 'white',
                	shadow:true,
                	showInLegend: false
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -40,
                y: 100,
                floating: true,
                borderWidth: 0,
               // backgroundColor: '#FFFFFF',
                shadow: true,
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{
					colorByPoint: true, 
            	 dataLabels: {
            	 	//color: '#000099'
            	 	},
                name: '". __('Tickets','dashboard')."',
                data: [
				";
				
				//zerar rows para segundo while
				$DB->dataSeek($query_grp_b, 0);
				
				while ($grupo = $DB->fetchAssoc($query_grp_b))
				{
					echo $grupo['conta'].",";
				}
				
				echo "]
            }]
        });
    });

</script>
";

		?>
