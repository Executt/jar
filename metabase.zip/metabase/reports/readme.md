# Reports directory.

Place here json files you want to push to metabase.
This folder can contains sub folders, the plugin will parse json files recursively.

For json file format, prepare your reports directly into metabase gui, and use extract process (from Setup > General menu) to store them here.
